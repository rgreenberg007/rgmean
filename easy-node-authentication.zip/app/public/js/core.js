angular.module('scotchTodo', ['todoController', 'todoService', 'todoGrpController', 'toDoGrpService']);
