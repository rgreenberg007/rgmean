angular.module('scotchTodo', ['todoController', 'todoService', 'toDoGrpController', 'toDoGrpService']);
